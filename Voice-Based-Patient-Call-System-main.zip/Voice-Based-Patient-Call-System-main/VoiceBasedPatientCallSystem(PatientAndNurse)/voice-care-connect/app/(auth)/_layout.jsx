import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const AuthLayout = () => {
  return (
    <View>
      <Text>AuthLayout</Text>
    </View>
  )
}

export default AuthLayout

const styles = StyleSheet.create({})